
var buff=new Buffer.from("Sample data");//directiny taking data from source and return to buff
console.log(buff.toString()); //to covert byte to string 'tostring' is used

var b=Buffer.alloc(1000); //1000 octet is reserved
var noOfBytesWritten=b.write("this is dample data");
console.log("bytes written:"+noOfBytesWritten);
console.log(b.toString());