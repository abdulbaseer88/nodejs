function sayHello(name,callback){
    //time consuming,long running operation here
    setTimeout(()=>{
        callback("hello"+name);
    },3000);
}
    console.log("calling sayhello()");
    sayHello("abc",function(result){
        console.log(result);//expected result is say hello
        console.log("completed");
    });
