
var EventEmitter=require("events").EventEmitter;
var ee=new EventEmitter(); //ee is eventemitter obeect
var timer;
ee.on("start",(startPos)=>{
    //registring an event with eventName "start" through EventEmitter obj(ee)
    //if on() is used, timer can also start even after timer stops
    //once() is used for only one time execution
    var i=startPos;
    console.log("starting timer");
    timer=setInterval(()=>{
        console.log(i);
        i++;
    },500) //500 is millisec
});
ee.on("stop",()=>{
    console.log("stop timer");
    clearInterval(timer);
})
ee.emit("start",100); //emit is used to raise the ( start) 'event'
setTimeout(()=>{
    ee.emit("stop");
    //ee.emit("start",50);
},10000);