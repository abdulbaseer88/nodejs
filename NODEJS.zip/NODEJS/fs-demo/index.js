
// console.log(__dirname);
// console.log(__filename);
var {writeContentSync,readContent, readContentSync,writeContent,readFileContent,writeFileContent}=require("./file-handler");
var data="hello,how are you AM AB?"
var filename ="greet3.txt"
var path = require("path")
var fs = require("fs");
var {writeToFileStream,readFromFileStream}=require("./stream-demo")
// writeContent(filename,data);

// readContent(filename);

// writeContentSync(filename,data);
// readContentSync(filename);
// readFileContent(filename);
// writeFileContent(filename,data);

// var filePath = path.resolve(__dirname, "myfiles", filename);
// fs.stat(filePath,(err,stats)=>{
//     console.log(stats);
// })

// var filePath = path.resolve(__dirname, "myfiles", filename);
// fs.watchFile(filePath,(prev,current)=>{ //(prev,current) is a listenr
//     console.log(prev.size+" --------"+current.size) ;
// })
writeToFileStream(filename,data);
readFromFileStream(filename)