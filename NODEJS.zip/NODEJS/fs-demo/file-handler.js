var fs = require("fs");
var path = require("path")
exports.writeContent = (filename, content) => {
    var filePath = path.resolve(__dirname, "myfiles", filename); //'this will be valid in all platforms 'resolve funct generte absolute path based on args passed and cretes the path appropiate
    fs.open(filePath, "w", (err, fd) => {
        if (err) {
            console.log("failed to open file content");
            return;
        }
        fs.write(fd, Buffer.from(content), (err, noOfBytes, buff) => {
            if (err) {
                console.log("failed to write content");
                return;
            }
            console.log("succesfullyt written the content");
            fs.close(fd, (err) => {
                if (err) {
                    console.log("error in closing the file");
                    return;
                }
                console.log("file closed");
            })
        })
    });
}


exports.readContent = (filename) => {
    var filePath = path.resolve(__dirname, "myfiles", filename); //'this will be valid in all platforms 'resolve funct generte absolute path based on args passed and cretes the path appropiate
    fs.open(filePath, "r", (err, fd) => {
        if (err) {
            console.log("failed to open file content");
            return;
        }
        var buffer = Buffer.alloc(1024);
        fs.read(fd, buffer, 0, 1024, 0, (err, bytesRead, buff) => {
            if (err) {
                console.log("failed to read");
                return;
            }
            console.log(buff.toString());
            fs.close(fd, (err) => {
                console.log("file closed");
            })
        })
    })
}
exports.writeContentSync = (filename, content) => {
    var filePath = path.resolve(__dirname, "myfiles", filename);
    var fd = fs.openSync(filePath, "w");
    if (!fd) {
        console.log("failed to open file")
        return;
    }
    var bytes = fs.writeSync(fd, Buffer.from(content));
    console.log("file written successfully")
    fs.closeSync(fd);

}
exports.readContentSync = (filename) => {
    var filePath = path.resolve(__dirname, "myfiles", filename);
    var fd = fs.openSync(filePath, "r");
    if (!fd) {
        console.log("failed to open file")
        return;
    }
    var buffer = Buffer.alloc(1024);
    var bytes = fs.readSync(fd, buffer, 0, 1024, 0);
    console.log(buffer.toString());
    fs.closeSync(fd);

}
exports.writeFileContent=(filename,content)=>{
    var filePath = path.resolve(__dirname, "myfiles", filename);
    fs.writeFile(filePath,content,(err)=>{
        if(err){
            console.log("err in wriiting file")
            return;
        }
        console.log("succesfully written in to file");
    })

}
exports.readFileContent=(filename)=>{
    var filePath = path.resolve(__dirname, "myfiles", filename);
    fs.readFile(filePath,{encoding:"utf-8"},(err,data)=>{
        if(err){
            console.log("err in reading file")
            return;
        }
        console.log(data);
    })

}

