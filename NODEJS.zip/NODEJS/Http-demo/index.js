var http=require("http");
var {requestHandler}=require("./request-handler") //importing request-handler
var server=http.createServer(requestHandler);
server.listen(3241,(err)=>{
    if(err){
        console.log("server coudn't start");
        return;
    }
    console.log("server started in port 3241");
})
